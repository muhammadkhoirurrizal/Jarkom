﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public Sprite[] SprGambar;
    public Image[] Gambar;
    public GameObject[] BtnMove;

    public bool Turn = true;
    bool Chaged = false;

    public int NoGambar,Nom;

    public int[] Prev;

    public static GameManager Instance;

    private void Start()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    private void Update()
    {
        if (Chaged)
        {
            Gambar[Nom].sprite = SprGambar[1];
            Chaged = false;
        }
    }

    public void Change(int No)
    {
        Nom = No;
        Chaged = true;
    }

    void CheckWin()
    {
        for (int a =0;a<Prev.Length;a++)
        {
            if (Prev[0]==NoGambar&& Prev[1] == NoGambar && Prev[2] == NoGambar)
            {
                Debug.Log("You Win");
            }else if (Prev[3] == NoGambar && Prev[4] == NoGambar && Prev[5] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[6] == NoGambar && Prev[7] == NoGambar && Prev[8] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[0] == NoGambar && Prev[3] == NoGambar && Prev[6] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[1] == NoGambar && Prev[4] == NoGambar && Prev[7] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[2] == NoGambar && Prev[5] == NoGambar && Prev[8] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[0] == NoGambar && Prev[4] == NoGambar && Prev[8] == NoGambar)
            {
                Debug.Log("You Win");
            }
            else if (Prev[2] == NoGambar && Prev[4] == NoGambar && Prev[6] == NoGambar)
            {
                Debug.Log("You Win");
            }
        }
    }

    // Use this for initialization
    public void PilihMove(int Pilih)
    {
        if (Turn)
        {
            NetworkManager.Instance.streamWriter.WriteLine(Pilih);
            NetworkManager.Instance.streamWriter.Flush();
            //Turn = false;
            if (Pilih == 0)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 1)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 2)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 3)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 4)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 5)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 6)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 7)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
            else if (Pilih == 8)
            {
                Gambar[Pilih].sprite = SprGambar[NoGambar];
                BtnMove[Pilih].SetActive(false);
                Prev[Pilih] = NoGambar;
                CheckWin();
            }
        }
    }
}
