﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.UI;

public class NetworkManager : MonoBehaviour {

    TcpClient tcpClient;
    public StreamWriter streamWriter;
    public GameManager Manager;
    public static NetworkManager Instance;

	// Use this for initialization
	void Start () {
        if (Instance==null)
        {
            Instance = this;
        }
        try
        {

            tcpClient = new TcpClient("127.0.0.1", 4444);
            Debug.Log("Connect To Server");

            Thread thread = new Thread(Read);
            thread.Start(tcpClient);
            streamWriter = new StreamWriter(tcpClient.GetStream());
            //StartCoroutine(Listening());
        }
        catch (Exception e)
        {
            Debug.Log(e.Message);
        }
    }

    IEnumerator Listening()
    {
        while (true)
        {
            if (tcpClient.Connected)
            {
                string input = ("OK");
                streamWriter.WriteLine(input);
                streamWriter.Flush();
            }
            yield return new WaitForSeconds(0.1f);
        }
    }

     void Read(object obj)
    {
        TcpClient tcpClient = (TcpClient)obj;
        StreamReader streamReader = new StreamReader(tcpClient.GetStream());

        while (true)
        {
            try
            {
                string message = streamReader.ReadLine();
                int No;
                Int32.TryParse(message, out No);
                Debug.Log(No);
                Manager.Change(No);
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
                break;
            }
        }
    }
}
