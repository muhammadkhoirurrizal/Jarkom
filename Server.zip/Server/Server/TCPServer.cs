﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class TcpServer
    {
        private TcpListener _server;
        private Boolean _isRunning;
        private StreamWriter _sWriter;
        private TcpClient[] To = new TcpClient[5];
        private int o = 0;

        public TcpServer(int port)
        {
            _server = new TcpListener(IPAddress.Any, port);
            _server.Start();

            _isRunning = true;

            LoopClients();
        }

        public void LoopClients()
        {
            while (_isRunning)
            {
                // wait for client connection
                 TcpClient newClient = _server.AcceptTcpClient();

                // client found.
                // create a thread to handle communication
                Thread t = new Thread(new ParameterizedThreadStart(HandleClient));
                t.Start(To[o]);
            }
        }

        public void HandleClient(object obj)
        {
            // retrieve client from parameter passed to thread
            TcpClient client = (TcpClient)obj;
            // sets two streams
            StreamWriter sWrite = new StreamWriter(client.GetStream(), Encoding.ASCII);
            StreamReader sReader = new StreamReader(client.GetStream(), Encoding.ASCII);
            // you could use the NetworkStream to read and write,
            // but there is no forcing flush, even when requested

            Boolean bClientConnected = true;
            String sData = null;


            while (bClientConnected)
            {

                // write data and make sure to flush, or the buffer will continue to
                // grow, and your data might not be sent when you want it, and will
                // only be sent once the buffer is filled.

                // reads from stream
                sData = sReader.ReadLine();

                // shows content on the console.
                Console.WriteLine("Client &gt; " + sData);

                // to write something back.
                sWrite.WriteLine("Meaningfull things here");
                sWrite.Flush();
            }
        }
    }
}
