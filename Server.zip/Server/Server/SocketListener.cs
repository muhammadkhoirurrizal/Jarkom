﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;


public class SocketListener
{
    public delegate void ClientConnected(string Client);
    public delegate void ClientDisconnected();
    public delegate void MessageRecieved(string Message);
    public delegate void MessageSent();

    public IPAddress LocalAddress { private set; get; }

    public ClientConnected OnClientConnected { set; get; }
    public ClientDisconnected OnClientDisconnected { set; get; }
    public MessageRecieved OnMessageRecieved { set; get; }
    public MessageSent OnMessageSent { set; get; }

    Socket Listener;
    Socket Handler;

    public const int BufferSize = 1024;
    public byte[] Buffer = new byte[BufferSize];

    public SocketListener()
    {
        Handler = null;
    }

    public void Initialize()
    {
        byte[] bytes = new Byte[1024];

        IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
        GetLocalAddress(ipHostInfo);
        IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Any, 11000);

        Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        Listener.Bind(localEndPoint);
        Listener.Listen(100);
    }

    public void StartListening()
    {
        try
        {
            Listener.BeginAccept(new AsyncCallback(AcceptCallback), Listener);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }
    }

    private void GetLocalAddress(IPHostEntry host)
    {
        foreach (IPAddress address in host.AddressList)
        {
            if (address.AddressFamily == AddressFamily.InterNetwork)
            {
                LocalAddress = address;
            }
        }
    }

    public void AcceptCallback(IAsyncResult ar)
    {
        Handler = Listener.EndAccept(ar);

        if (OnClientConnected != null)
            SynchronizationContext.Current.Post(o => OnClientConnected(Handler.RemoteEndPoint.ToString()), null);

        Handler.BeginReceive(Buffer, 0, BufferSize, 0, new AsyncCallback(ReadCallback), null);
    }

    public void ReadCallback(IAsyncResult ar)
    {
        try
        {
            int bytesRead = Handler.EndReceive(ar);

            if (bytesRead >0)
            {
                string message = Encoding.ASCII.GetString(Buffer, 0, bytesRead);

                if (OnMessageRecieved != null)
                    SynchronizationContext.Current.Post(o => OnMessageRecieved(message), null);
            }

            Handler.BeginReceive(Buffer, 0, BufferSize, 0, new AsyncCallback(ReadCallback), null);
        }
        catch
        {
            Handler.Close();
            Handler = null;
            StartListening();

            if (OnClientDisconnected != null)
                SynchronizationContext.Current.Post(o => OnClientDisconnected(), null);
        }
    }

    public void Send(string data)
    {
        byte[] byteData = Encoding.ASCII.GetBytes(data + "\r\n");


        Handler.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCallback), null);

    }

    private void SendCallback(IAsyncResult ar)
    {
        try
        {
            int bytesSent = Handler.EndSend(ar);

            if (OnMessageSent != null)
                SynchronizationContext.Current.Post(o => OnMessageSent(), null);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }
    }
}

